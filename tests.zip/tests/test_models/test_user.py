#!/usr/bin/python3
import unittest
from models.user import User
""" Unitest for User class """

models = User()


class test_user(unittest.TestCase):
    """ test cases """

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_init(self):
        pass


if __name__ == "__main__":
    unittest.main()
