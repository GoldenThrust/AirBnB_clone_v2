#!/usr/bin/python3
import unittest
from models.review import Review
""" Unitest for review class """

models = Review()


class test_review(unittest.TestCase):
    """ test cases """

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_init(self):
        pass


if __name__ == "__main__":
    unittest.main()
