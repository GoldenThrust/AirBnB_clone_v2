#!/usr/bin/python3
import unittest
from models.city import City
""" Unitest for City class """

models = City()


class test_city(unittest.TestCase):
    """ test cases """

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_init(self):
        pass


if __name__ == "__main__":
    unittest.main()
