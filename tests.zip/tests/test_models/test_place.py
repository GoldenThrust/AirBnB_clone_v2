#!/usr/bin/python3
import unittest
from models.place import Place
""" Unitest for Place class """

models = Place()


class test_place(unittest.TestCase):
    """ test cases """

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_init(self):
        pass


if __name__ == "__main__":
    unittest.main()
